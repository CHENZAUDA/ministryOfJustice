import './App.css';
import React, { useState, useEffect } from 'react';
import Users from './components/Pages/Users/Users';
function App() {


  return (
    <div className="App">
      <Users/>
    </div>
  );
}

export default App;
